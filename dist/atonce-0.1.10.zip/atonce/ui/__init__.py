"""AtOnce QGIS user interface."""
