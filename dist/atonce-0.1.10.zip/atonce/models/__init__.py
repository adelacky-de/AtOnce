"""Shared AtOnce application models."""
